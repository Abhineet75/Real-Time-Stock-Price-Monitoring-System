import os
from datetime import datetime
from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


def val_sort(d):
    return d["value"]


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""



    # stock owned, stock price, number of shares, total value of each holding,
    # display cash balance
    # grand asset value

    # make a table called owned_stocks? id it to the user
    # I can technically get it from the transactions... but that is not the best.
    # stock_id, person_id, symbol, shares, buying_price.

    # CREATE TABLE stocks_owned(
    #     stock_entry_id INTEGER PRIMARY KEY AUTOINCREMENT,
    #     person_id INTEGER NOT NULL,
    #     symbol TEXT NOT NULL,
    #     shares INTEGER NOT NULL,
    #     share_price FLOAT NOT NULL
    # );

    stock_symbols_all = db.execute("SELECT symbol FROM stocks_owned WHERE person_id = (?)", session["user_id"])
    stock_symbols = set()
    for x in stock_symbols_all:
        stock_symbols.add(x["symbol"])

    print(stock_symbols)

    stocks = []

    # <td>stock["stock_name"]</td>
    #             <td>stock["symbol"]</td>
    #             <td>stock["shares"]</td>
    #             <td>stock["acquired"]</td>
    #             <td>stock["present"]</td>
    #             <td>stock["balance"]</td>


    tot = dict()
    tot["invested"] = 0
    tot["value"] = 0
    tot["net"] = 0

    for symb in stock_symbols:
        stk = dict()
        stk_vals = lookup(symb)

        stk["stock_name"] = stk_vals["name"]

        total_shares = db.execute("SELECT SUM(shares) AS total FROM stocks_owned WHERE person_id=(?) AND symbol=(?)", session["user_id"], symb)
        acquired_value = db.execute("SELECT SUM(shares * share_price) AS aq FROM stocks_owned WHERE person_id=(?) AND symbol=(?)", session["user_id"], symb)
        present_value = total_shares[0]["total"] * stk_vals["price"]
        balance = present_value - acquired_value[0]["aq"]

        stk["symbol"] = symb
        stk["shares"] = total_shares[0]['total']
        stk["acquired"] = acquired_value[0]['aq']
        stk["present"] = present_value
        stk["balance"] = balance

        tot["invested"]+= acquired_value[0]['aq']
        tot["value"] += present_value
        tot["net"] += balance

        stocks.append(stk)

    csh = db.execute("SELECT cash FROM users WHERE id=(?)", session["user_id"])
    cash = csh[0]["cash"]

    tot["cash"] = cash

    stocks = sorted(stocks, key = lambda x : x["present"], reverse=True)

    user_name = db.execute("SELECT username FROM users WHERE id=(?)", session["user_id"])
    ume = user_name[0]["username"]


    return render_template("index.html", username=ume, stocks=stocks, tot=tot)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""

    if request.method == "POST":

        symbol = request.form.get("symbol")

        if not symbol:
            return apology("user did not enter a symbol", 400)

        stk = lookup(symbol)

        if stk == None:
            return apology("this stock does not exist", 400)

        number = request.form.get("shares")

        try:
            number = int(number)
        except Exception as e:
            return apology(f"{e}", 400)

        if number < 1:
            return apology("invalid number of shares entered", 400)



        user_id = session["user_id"]

        cash_kv = db.execute("SELECT cash FROM users WHERE id = (?)", user_id)
        cash = cash_kv[0]["cash"]

        amount = stk["price"] * number

        if cash < amount:
            return apology("user has insufficient funds", 400)

        balance = cash - amount

        db.execute("UPDATE users SET cash=(?) WHERE id=(?)", balance, user_id)

        # now update the purchases database

        db.execute("INSERT INTO transactions (person_id, type, symbol, shares, share_price, net_price, bought_on) VALUES (?, ?, ?, ?, ?, ?, ?)", session["user_id"], "BUY", symbol, number, stk["price"], stk["price"]*number, datetime.now())
        # note that the share price is at buying. Later we can display the profit also.

        # if that particular stock is already owned, just update the number
        own = db.execute("SELECT * FROM stocks_owned WHERE person_id=(?) AND symbol=(?)", session["user_id"], symbol)

        print(own)

        # okay so first search if there exists stocks of the same company that have the same price

        x = db.execute("SELECT * FROM stocks_owned WHERE person_id=(?) AND symbol=(?) AND share_price=(?)", session["user_id"], symbol, stk["price"])

        if len(x) == 0:
            db.execute("INSERT INTO stocks_owned (person_id, symbol, shares, share_price) VALUES (?, ?, ?, ?)", session["user_id"], symbol, number, stk["price"])
        elif len(x) == 1:
            db.execute("UPDATE stocks_owned SET shares=(?) WHERE stock_entry_id=(?)", x[0]["shares"] + number, x[0]["stock_entry_id"])
        else:
            return apology("There are multiple entries for stocks of the same company that have the same price", 400)


        return redirect("/")

    else:

        return render_template("buy.html")



@app.route("/history")
@login_required
def history():
    """Show history of transactions"""

    transac = db.execute("SELECT * FROM transactions WHERE person_id=(?) ORDER BY bought_on DESC", session["user_id"])

    return render_template("history.html", transac=transac)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        session["username"] = rows[0]["username"]

        print("You have reached here without any error!")

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required

def quote():
    """Get stock quote."""

    if request.method == "POST":

        # when the user enters, the user enters on quote.html
        # the info has to show on quoted.html

        # after submitting the form via post, you should render the quoted html.
        # and checking for proper submitting

        stk_name = request.form.get("symbol")

        if not stk_name:
            return apology("empty input", 400)

        stk = lookup(stk_name) # the errors are handled in lookup itself

        if stk == None:
            return apology("invalid name of stock", 400)

        return render_template("quoted.html", stk=stk)
    else:

        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    if request.method == "POST":

        name = request.form.get("username")

        if not name:
            return apology("user did not enter a username", 400)

        password = request.form.get("password")
        cpass = request.form.get("confirmation")

        if not password or not cpass:
            return apology("user did not enter password(s) correctly", 400)

        if password != cpass:
            return apology("the passwords did not match", 400)


        try:

            p_hash = generate_password_hash(password)
            db.execute("INSERT INTO users (username, hash) VALUES (?, ?)", name, p_hash)

        except ValueError:
            return apology("Cannot have duplicate users", 400)
        except Exception as e:
            return apology(f"{e}", 400)

        return redirect("/login")

    else:

        return render_template("register.html")


@app.route("/change_password", methods=["GET", "POST"])
@login_required
def change_password():


    # here we try to use the same page!

    if request.method == "POST":

        stage = request.form.get("stage")
        if stage == "check_old":
            old_password = request.form.get("old_password")

            if not old_password:
                return apology("must provide old password", 403)

            user = db.execute("SELECT * FROM users WHERE id = ?", session["user_id"])

            if not user or not check_password_hash(user[0]["hash"], old_password):
                return apology("old password is incorrect", 403)

            return render_template("change.html", stage="new")

        elif stage == "set_new":
            new_password = request.form.get("new_password")

            if not new_password:
                return apology("Must provide new password", 403)

            hash_pw = generate_password_hash(new_password)
            db.execute("UPDATE users SET hash = ? WHERE id = ?", hash_pw, session["user_id"])

            return render_template("changed.html")
    # Default: Show old password check form
    return render_template("change.html", stage="old")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""


    if request.method == "POST":

        symbol = request.form.get("symbol")
        shares = request.form.get("shares")

        try:
            shares = int(shares)
        except Exception as e:
            return apology(f"{e}", 400)


        if not symbol:
            return apology("enter valid name of stock", 400)

        ustk = db.execute("SELECT stock_entry_id, shares FROM stocks_owned WHERE person_id =(?) AND symbol=(?) ORDER BY share_price", session["user_id"], symbol)
        if (len(ustk) == 0):
            return apology("user does not have stocks of this company", 400)

        if shares < 1:
            return apology("invalid number of stocks entered", 400)

        us = db.execute("SELECT SUM(shares) AS total FROM stocks_owned WHERE person_id=(?) AND symbol=(?)", session["user_id"], symbol)
        user_shares = us[0]["total"]

        if shares > user_shares:
            return apology("user does not have enough stocks", 400)

        # first get all the stocks of this
        # order by asc order of share price
        # then choose the first shares best to sell.

        sum = 0
        cash_earned = 0

        this_stock = lookup(symbol)

        #  update the transactions at the end only
        # which can be done at the very end actually

        for s in ustk:
            if sum + s["shares"] >= shares:
                needed = shares - sum
                cash_earned += this_stock["price"] * needed

                if needed == s["shares"]:
                    db.execute("DELETE FROM stocks_owned WHERE stock_entry_id=(?)", s["stock_entry_id"]) # finished stocks
                else:
                    db.execute("UPDATE stocks_owned SET shares=(?) WHERE stock_entry_id=(?)", s["shares"] - needed, s["stock_entry_id"])

                break

            cash_earned = this_stock["price"] * s["shares"]
            sum += s["shares"]
            db.execute("DELETE FROM stocks_owned WHERE stock_entry_id=(?)", s["stock_entry_id"]) # finished stocks


        db.execute("UPDATE users SET cash=cash+(?) WHERE id=(?)", cash_earned, session["user_id"])
        db.execute("INSERT INTO transactions (person_id, type, symbol, shares, share_price, net_price, bought_on) VALUES (?,?,?,?,?,?,?)", session["user_id"], "SELL", symbol, shares, this_stock["price"], shares*this_stock["price"], datetime.now())

        return redirect("/")

    else:
        stock_symbols_all = db.execute("SELECT symbol FROM stocks_owned WHERE person_id = (?)", session["user_id"])
        stock_symbols = set()
        for x in stock_symbols_all:
            stock_symbols.add(x["symbol"])

        return render_template("sell.html", stocks=stock_symbols)
